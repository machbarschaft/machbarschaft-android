package com.ks.einanrufhilft.view.blabla;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.ks.einanrufhilft.R;

public class PhoneAuthstart extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_authstart);
    }
}
